package com.hongyi;

public class Game extends ACG{
    private String platform;//游戏平台
    private String sort;//游戏类型
    private boolean offline;//游戏是不是联网的
    //构造函数
    public Game(String name,String style,String author,String platform,String sort,boolean offline){
        setName(name);
        setStyle(style);
        setAuthor(author);
        this.platform = platform;
        this.sort = sort;
        this.offline = offline;
    }
    public Game(){
        this("MUSH DASH","休闲","PeroPeroGames","PC","音乐节奏",false);
    }
    public void setPlatform(String platform){
        this.platform = platform;
    }
    public void setSort(String form){
        this.sort = form;
    }
    public void setOffline(boolean offline){
        this.offline = offline;
    }
    public String getPlatform(){
        return platform;
    }
    public boolean getOffline(){
        return offline;
    }
    public String getSort(){
        return sort;
    }
    public void  Print(){
        System.out.println("这个游戏叫做" + getName() + ",它属于" + getStyle() + "类型" + ",它是" + getPlatform() + "平台的游戏,它是否是单机游戏" + getOffline() + ",它的分类是" + getSort() + "游戏" + ",它是" + getAuthor() + "的作品.");
    }
}
