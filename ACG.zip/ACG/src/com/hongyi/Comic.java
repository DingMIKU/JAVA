package com.hongyi;

public class Comic extends ACG{
    private String country;//哪个国家的
    private String form;//连载状态
    private boolean fullcolor;//是否全彩
    //构造函数
    public Comic(String name,String style,String author,String country,String form,boolean Fullcolor){
        super("name","style","author");
        this.country = country;
        this.form = form;
        this.fullcolor = Fullcolor;
    }
    public Comic(){
        this("鬼灭之刃","热血","吾峠呼世晴","日本","连载中",false);
    }
    public void setCountry(String country){
        this.country = country;
    }
    public void setForm(String form){
        this.form = form;
    }
    public void setFullcolor(boolean fullcolr){
        this.fullcolor = fullcolr;
    }
    public String getCountry(){
        return country;
    }
    public boolean getFullcolor(){
        return fullcolor;
    }
    public String getForm(){
        return form;
    }
    public void  Print(){
        System.out.println("这部漫画叫做" + getName() + ",它属于" + getStyle() + "类型" + ",它是" + getCountry() + "的漫画,它的全彩情况是" + getFullcolor() + ",它的形式是" + getForm() + ",它是" + getAuthor() + "的作品.");
    }
}
