package com.hongyi;

public class Animation extends ACG{
    private int year;//动漫的发布年份
    private boolean vip;//是否需要vip.
    private boolean serialization;//是否在连载
    //构造函数
    public Animation(String name,String style,String author,int year, boolean vip, boolean serialization){
        setName(name);
        setStyle(style);
        setAuthor(author);
        this.year = year;
        this.vip = vip;
        this.serialization = serialization;
    }
    public Animation(){
        this("蜘蛛子","搞笑日常","马场翁",2021,true,true);
    }
    public void setTime(int year){
        this.year= year;
    }
    public void setVIP(boolean vip){
        this.vip = vip;
    }
    public void setSerialization(boolean serialization){
        this.serialization = serialization;
    }
    public int getYear(){
        return year;
    }
    public boolean getVIP(){
        return vip;
    }
    public boolean getSerialization(){
        return serialization;
    }
    public void  Print(){
        System.out.println("这部动漫叫做" + getName() + ",它属于" + getStyle() + "类型" + ",它的发布时间是" + getYear() + ",它的VIP需求情况是" + getVIP() + ",它的连载情况是" + getSerialization() + ",它是" + getAuthor() + "的作品.");
    }


}
