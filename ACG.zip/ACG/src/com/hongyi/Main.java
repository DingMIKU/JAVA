package com.hongyi;

public class Main {

    public static void main(String[] args) {
        Animation a1 = new Animation();
        a1.Print();
        Comic c1 = new Comic();
        c1.Print();
        Game g1 = new Game();
        g1.Print();
        ACG a2 = new ACG();
        a2.Print();
    }

}
