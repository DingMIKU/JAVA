package com.company;

public class Comic extends ACG{
    private String country;
    private String form;
    private boolean Fullcolor;
    public Comic(String name,String style,String author,String country,String form,boolean Fullcolor){
        setName(name);
        setStyle(style);
        setAuthor(author);
        this.country = country;
        this.form = form;
        this.Fullcolor = Fullcolor;
    }
    public Comic(){
        this("鬼灭之刃","热血","吾峠呼世晴","日本","连载中",false);
    }
    public void setCountry(String country){
        this.country = country;
    }
    public void setForm(String form){
        this.form = form;
    }
    public void setFullcolor(boolean Fullcolr){
        this.Fullcolor = Fullcolr;
    }
    public String getCountry(){
        return country;
    }
    public boolean getFullcolor(){
        return Fullcolor;
    }
    public String getForm(){
        return form;
    }
    public void  Print(){
        System.out.println("这部漫画叫做" + getName() + ",它属于" + getStyle() + "类型" + ",它是" + getCountry() + "的漫画,它的全彩情况是" + getFullcolor() + ",它的形式是" + getForm() + ",它是" + getAuthor() + "的作品.");
    }
}
