package com.company;

public class ACG {
    private String name;//作品名
    private String style;//作品类型
    private String author;//作者
    public ACG(String name,String style,String author){
        this.name = name;
        this.style = style;
        this.author = author;
    }
    public ACG(){
        this("none","none","none");
    }
    public void setName(String name){
        this.name = name;
    }
    public void setStyle(String style){
        this.name = style;
    }
    public void setAuthor(String author){
        this.author = author;
    }
    public String getName(){
        return name;
    }
    public String getStyle(){
        return style;
    }
    public String getAuthor(){
        return author;
    }
    public void  Print(){
        System.out.println("这个作品叫做" + getName() + ",它属于" + getStyle() + "类型" + ",它是" + getAuthor() + "的作品.");
    }
}
